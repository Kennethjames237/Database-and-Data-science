CREATE TABLE LOCATION(
   ID_location INTEGER  NOT NULL PRIMARY KEY,
   City        VARCHAR(9) NOT NULL,
   Province    VARCHAR(20) NOT NULL,
   Region      VARCHAR(20) NOT NULL
);
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (106,'Padova','Padova','Veneto');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (107,'Este','Padova','Veneto');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (109,'Monselice','Padova','Veneto');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (112,'Teolo','Padova','Veneto');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (114,'Tribano','Padova','Veneto');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (120,'Conselve','Padova','Veneto');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (122,'Treviso','Treviso','Veneto');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (124,'Asolo','Treviso','Veneto');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (127,'Oderzo','Treviso','Veneto');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (129,'Possagno','Treviso','Veneto');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (134,'Resana','Treviso','Veneto');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (745,'Torino','Torino','Piemonte');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (758,'Rivoli','Torino','Piemonte');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (759,'Chieri','Torino','Piemonte');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (764,'Cuneo','Cuneo','Piemonte');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (770,'Alba','Cuneo','Piemonte');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (771,'Bra','Cuneo','Piemonte');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (777,'Asti','Asti','Piemonte');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (784,'Canelli','Asti','Piemonte');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (789,'Moncalvo','Asti','Piemonte');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (791,'Biella','Biella','Piemonte');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (792,'Cossato','Biella','Piemonte');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (793,'Valdengo','Biella','Piemonte');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (865,'Novara','Novara','Piemonte');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (866,'Arona','Novara','Piemonte');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (870,'Gozzano','Novara','Piemonte');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (876,'Trecate','Novara','Piemonte');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (878,'Oleggio','Novara','Piemonte');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (879,'Cameri','Novara','Piemonte');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (882,'Vercelli','Vercelli','Piemonte');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (884,'Trino','Vercelli','Piemonte');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (890,'Varallo','Vercelli','Piemonte');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (891,'Gattinara','Vercelli','Piemonte');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (892,'Rovasenda','Vercelli','Piemonte');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (893,'Balocco','Vercelli','Piemonte');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (895,'Bergamo','Bergamo','Lombardia');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (897,'Seriate','Bergamo','Lombardia');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (898,'Dalmine','Bergamo','Lombardia');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (904,'Treviglio','Bergamo','Lombardia');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (907,'Clusone','Bergamo','Lombardia');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (909,'Lovere','Bergamo','Lombardia');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (910,'Brescia','Brescia','Lombardia');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (911,'Chiari','Brescia','Lombardia');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (912,'Iseo','Brescia','Lombardia');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (913,'Manerbio','Brescia','Lombardia');
INSERT INTO LOCATION(ID_location,City,Province,Region) VALUES (914,'Ghedi','Brescia','Lombardia');
